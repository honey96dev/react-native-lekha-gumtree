package com.driverapp;

import android.app.Application;

import com.facebook.react.ReactApplication;
import com.airbnb.android.react.maps.MapsPackage;
import com.microsoft.codepush.react.CodePush;
import com.beefe.picker.PickerViewPackage;
import com.microsoft.codepush.react.ReactInstanceHolder;
import com.react.rnspinkit.RNSpinkitPackage;
import com.rnappauth.RNAppAuthPackage;
import com.swmansion.gesturehandler.react.RNGestureHandlerPackage;
import com.oblador.vectoricons.VectorIconsPackage;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.soloader.SoLoader;

import java.util.Arrays;
import java.util.List;

public class MainApplication extends Application implements ReactApplication {
    private final ReactNativeHost mReactNativeHost = new MyReactNativeHost(this);

    @Override
    public ReactNativeHost getReactNativeHost() {
        return mReactNativeHost;
    }

    @Override
    public void onCreate() {
        CodePush.setReactInstanceHolder((ReactInstanceHolder) mReactNativeHost);
        super.onCreate();
        SoLoader.init(this, /* native exopackage */ false);
    }

    class MyReactNativeHost extends ReactNativeHost implements ReactInstanceHolder {

        protected MyReactNativeHost(Application application) {
            super(application);
        }

        @Override
        protected String getJSBundleFile() {
            return CodePush.getJSBundleFile();
        }

        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            return Arrays.<ReactPackage>asList(
                    new MainReactPackage(),
                    new MapsPackage(),
                    new CodePush(getResources().getString(R.string.reactNativeCodePush_androidDeploymentKey), getApplicationContext(), BuildConfig.DEBUG),
                    new PickerViewPackage(),
                    new RNSpinkitPackage(),
                    new RNAppAuthPackage(),
                    new RNGestureHandlerPackage(),
                    new VectorIconsPackage()
            );
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }
    }
}
